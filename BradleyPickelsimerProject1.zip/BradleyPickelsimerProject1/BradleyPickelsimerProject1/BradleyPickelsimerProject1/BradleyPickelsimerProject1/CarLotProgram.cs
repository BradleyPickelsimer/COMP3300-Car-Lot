﻿using System;
using System.Windows.Forms;
using BradleyPickelsimerProject1.View;

namespace BradleyPickelsimerProject1
{
    internal static class CarLotProgram
    {
        #region Methods

        /// <summary>
        ///     The main entry point for the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new CarLotForm());
        }

        #endregion
    }
}