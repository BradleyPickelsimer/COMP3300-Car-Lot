﻿using System.Collections.Generic;

namespace BradleyPickelsimerProject1.Model
{
    /// <summary>
    ///     Entry point to the Car lot class.
    /// </summary>
    public class CarLot
    {
        #region Data members

        /// <summary>
        ///     The tax rate.
        /// </summary>
        public const double TaxRate = 0.066;

        #endregion

        #region Properties

        /// <summary>
        ///     Gets the inventory.
        /// </summary>
        /// <value>
        ///     The inventory.
        /// </value>
        public List<Car> Inventory { get; }

        /// <summary>
        ///     Gets the count.
        /// </summary>
        /// <value>
        ///     The count.
        /// </value>
        public int Count => this.Inventory.Count;

        #endregion

        #region Constructors

        public CarLot()
        {
            this.Inventory = new List<Car>();
            this.stockLotWithDefaultInventory();
        }

        #endregion

        #region Methods

        private void stockLotWithDefaultInventory()
        {
            this.Inventory.Add(new Car("Ford", "Focus ST", 28.3, 26298.98));
            this.Inventory.Add(new Car("Chevrolet", "Camaro ZL1", 19.0, 65401.23));
            this.Inventory.Add(new Car("Honda", "Accord Sedan EX", 30.2, 26780.00));
            this.Inventory.Add(new Car("Lexus", "ES 350", 24.1, 42101.10));
        }

        /// <summary>
        ///     Finds the cars by make.
        /// </summary>
        /// <param name="make">The make.</param>
        /// <returns> A list of cars matching the given make, or null if the list is empty.</returns>
        public List<Car> FindCarsByMake(string make)
        {
            var matchingCars = new List<Car>();
            foreach (var car in this.Inventory)
            {
                if (car.Make.ToLower() == make.ToLower())
                {
                    matchingCars.Add(car);
                }
            }

            if (matchingCars.Count > 0)
            {
                return matchingCars;
            }

            return null;
        }

        /// <summary>
        ///     Finds the car by make model.
        /// </summary>
        /// <param name="make">The make.</param>
        /// <param name="model">The model.</param>
        /// <returns>The car matching the given make and model. Null if no car in the inventory matches.</returns>
        public Car FindCarByMakeModel(string make, string model)
        {
            Car matchingCar = null;
            foreach (var car in this.Inventory)
            {
                if ((car.Make.ToLower() == make.ToLower()) & (car.Model.ToLower() == model.ToLower()))
                {
                    matchingCar = car;
                }
            }

            return matchingCar;
        }

        /// <summary>
        ///     Removes the purchased car from the inventory.
        /// </summary>
        /// <param name="make">The make.</param>
        /// <param name="model">The model.</param>
        /// <returns>The car removed from the inventory if the car is in the inventory, null if otherwise.</returns>
        public Car PurchaseCar(string make, string model)
        {
            Car boughtCar = null;
            foreach (var car in this.Inventory)
            {
                if ((car.Make.ToLower() == make.ToLower()) & (car.Model.ToLower() == model.ToLower()))
                {
                    boughtCar = car;
                }
            }

            return boughtCar;
        }

        /// <summary>
        ///     Adds a car to the inventory.
        /// </summary>
        /// <param name="make">The make.</param>
        /// <param name="model">The model.</param>
        /// <param name="mpg">The MPG.</param>
        /// <param name="price">The price.</param>
        public void AddCar(string make, string model, double mpg, double price)
        {
            this.Inventory.Add(new Car(make, model, mpg, price));
        }

        /// <summary>
        ///     Gets the total cost of purchase.
        /// </summary>
        /// <param name="car">The car.</param>
        /// <returns>The total cost of purchase.</returns>
        public static double GetTotalCostOfPurchase(Car car)
        {
            var priceOfPurchase = car.Price + car.Price * TaxRate;
            return priceOfPurchase;
        }

        /// <summary>
        ///     Finds the least expensive car in the car lot.
        /// </summary>
        /// <returns>The cheapest car.</returns>
        public Car FindLeastExpensiveCar()
        {
            Car cheapestCar = null;
            if (this.Count == 0)
            {
                return null;
            }

            var cheapestCarPrice = double.MaxValue;
            foreach (var car in this.Inventory)
            {
                if (car.Price < cheapestCarPrice)
                {
                    cheapestCarPrice = car.Price;
                    cheapestCar = car;
                }
            }

            return cheapestCar;
        }

        /// <summary>
        ///     Finds and returns the most expensive car in the car lot.
        /// </summary>
        /// <returns>The most expensive car.</returns>
        public Car FindMostExpensiveCar()
        {
            Car mostExpensiveCar = null;
            if (this.Count == 0)
            {
                return null;
            }

            var mostExpensiveCarPrice = double.MinValue;
            foreach (var car in this.Inventory)
            {
                if (car.Price > mostExpensiveCarPrice)
                {
                    mostExpensiveCarPrice = car.Price;
                    mostExpensiveCar = car;
                }
            }

            return mostExpensiveCar;
        }

        /// <summary>
        ///     Finds and returns the car with the best MPG.
        /// </summary>
        /// <returns>The best mpg car.</returns>
        public Car FindBestMpgCar()
        {
            Car bestMpgCar = null;
            if (this.Count == 0)
            {
                return null;
            }

            var bestMpg = double.MinValue;
            foreach (var car in this.Inventory)
            {
                if (car.Mpg > bestMpg)
                {
                    bestMpg = car.Mpg;
                    bestMpgCar = car;
                }
            }

            return bestMpgCar;
        }

        /// <summary>
        ///     Finds and returns the car with the worst MPG.
        /// </summary>
        /// <returns>The worst MPG car.</returns>
        public Car FindWorstMpgCar()
        {
            Car worstMpgCar = null;
            if (this.Count == 0)
            {
                return null;
            }

            var worstMpg = double.MaxValue;
            foreach (var car in this.Inventory)
            {
                if (car.Mpg < worstMpg)
                {
                    worstMpg = car.Mpg;
                    worstMpgCar = car;
                }
            }

            return worstMpgCar;
        }

        #endregion
    }
}