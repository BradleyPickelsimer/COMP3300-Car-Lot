﻿using System;
using System.Collections.Generic;
// ReSharper disable CollectionNeverQueried.Local

namespace BradleyPickelsimerProject1.Model
{
    /// <summary>
    ///     Entry into the shopper class.
    /// </summary>
    public class Shopper
    {
        #region Data members

        private readonly List<Car> cars;

        #endregion

        #region Properties

        /// <summary>
        ///     Gets or sets the name of the shopper.
        /// </summary>
        /// <value>
        ///     The name of the shopper.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        ///     Gets or sets the money available for the shopper.
        /// </summary>
        /// <value>
        ///     The money available for the shopper.
        /// </value>
        public double MoneyAvailable { get; set; }

        #endregion

        #region Constructors

        private Shopper()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="Shopper" /> class.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <param name="moneyAvailable">The money available.</param>
        /// <exception cref="System.ArgumentException"></exception>
        /// <exception cref="System.ArgumentOutOfRangeException"></exception>
        /// <exception cref="System.ArgumentNullException"></exception>
        public Shopper(string name, double moneyAvailable)
        {
            if (name == string.Empty)
            {
                throw new ArgumentException();
            }

            if (moneyAvailable < 0)
            {
                throw new ArgumentOutOfRangeException();
            }

            this.Name = name ?? throw new ArgumentNullException();
            this.MoneyAvailable = moneyAvailable;
            this.cars = new List<Car>();
        }

        #endregion

        #region Methods

        /// <summary>
        ///     Determines whether this instance can purchase the specified car.
        /// </summary>
        /// <param name="car">The car.</param>
        /// <returns>
        ///     <c>true</c> if this instance can purchase the specified car; otherwise, <c>false</c>.
        /// </returns>
        public bool CanPurchase(Car car)
        {
            if (this.MoneyAvailable > car.Price * CarLot.TaxRate)
            {
                return true;
            }

            return false;
        }

        public void PurchaseCar(Car car)
        {
            this.cars.Add(car);
            this.MoneyAvailable -= CarLot.GetTotalCostOfPurchase(car);
        }

        #endregion
    }
}