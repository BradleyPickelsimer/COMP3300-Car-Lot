﻿using System;
using System.Globalization;

namespace BradleyPickelsimerProject1.Model
{
    /// <summary>
    ///     Entry to the car class
    /// </summary>
    public class Car
    {
        #region Properties

        /// <summary>
        ///     Gets or sets the make of the car
        /// </summary>
        /// <value>
        ///     The make of the car
        /// </value>
        public string Make { get; set; }

        /// <summary>
        ///     Gets or sets the model of the car.
        /// </summary>
        /// <value>
        ///     The model of the car
        /// </value>
        public string Model { get; set; }

        /// <summary>
        ///     Gets or sets the MPG of the car.
        /// </summary>
        /// <value>
        ///     The MPG of the car.
        /// </value>
        public double Mpg { get; set; }

        /// <summary>
        ///     Gets or sets the price of the car.
        /// </summary>
        /// <value>
        ///     The price of the car.
        /// </value>
        public double Price { get; set; }

        #endregion

        #region Constructors

        private Car()
        {
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="Car" /> class.
        /// </summary>
        /// <param name="make">The make.</param>
        /// <param name="model">The model.</param>
        /// <param name="mpg">The MPG.</param>
        /// <param name="price">The price.</param>
        /// <exception cref="System.ArgumentNullException">
        ///     make
        ///     or
        ///     model
        /// </exception>
        /// <exception cref="System.ArgumentOutOfRangeException">
        ///     mpg
        ///     or
        ///     price
        /// </exception>
        public Car(string make, string model, double mpg, double price)
        {
            this.Make = make ?? throw new ArgumentNullException(nameof(make));
            this.Model = model ?? throw new ArgumentNullException(nameof(model));
            if ((mpg < 0) | (mpg > 300000))
            {
                throw new ArgumentOutOfRangeException(nameof(mpg));
            }

            this.Make = make;

            if (price < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(price));
            }

            this.Price = price;
            if (mpg < 0)
            {
                throw new ArgumentOutOfRangeException(nameof(mpg));
            }

            this.Mpg = mpg;
        }

        #endregion

        #region Methods

        public override string ToString()
        {
            var setPrecision = new NumberFormatInfo();
            setPrecision.NumberDecimalDigits = 1;
            return
                $"{this.Make} {this.Model} {this.Price.ToString("C", CultureInfo.CurrentCulture)} {this.Mpg.ToString("N", setPrecision)}mpg";
        }

        #endregion
    }
}