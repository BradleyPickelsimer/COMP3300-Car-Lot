﻿using System;
using System.Windows.Forms;

namespace BradleyPickelsimerProject1.View
{
    public partial class SearchByMakeForm : Form
    {
        public  String SearchPhrase { get; set; }
        public SearchByMakeForm()
        {
            InitializeComponent();
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            this.SearchPhrase = this.makeSearchTextBox.Text.ToLower();
            DialogResult = DialogResult.OK;
        }
    }
}
