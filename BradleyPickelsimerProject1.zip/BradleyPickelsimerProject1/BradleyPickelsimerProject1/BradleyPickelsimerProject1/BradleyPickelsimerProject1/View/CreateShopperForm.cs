﻿using System;
using System.Windows.Forms;
using BradleyPickelsimerProject1.Model;

namespace BradleyPickelsimerProject1.View
{
    public partial class CreateShopperForm : Form
    {
        /// <summary>
        /// Creates a new shopper.
        /// </summary>
        public Shopper Shopper { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateShopperForm"/> class.
        /// </summary>
        public CreateShopperForm()
        {
            this.InitializeComponent();
        }
        private void createShopperButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.Shopper = this.createShopper();
            }
            catch
            {
                MessageBox.Show(@"Missing or invalid data.", @"Error", MessageBoxButtons.OK);
            }

            DialogResult = DialogResult.OK;
        }

        private Shopper createShopper()
        {
            var name = this.shopperNameTextBox.Text;
            var money = Convert.ToDouble(this.shopperMoneyTextBox.Text);

            Shopper shopper = new Shopper(name, money);
            return shopper;
        }
    }
}
