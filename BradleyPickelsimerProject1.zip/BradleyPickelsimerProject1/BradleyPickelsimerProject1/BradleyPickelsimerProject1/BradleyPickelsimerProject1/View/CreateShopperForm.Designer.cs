﻿namespace BradleyPickelsimerProject1.View
{
    partial class CreateShopperForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.shopperNameLabel = new System.Windows.Forms.Label();
            this.shopperMoneyLabel = new System.Windows.Forms.Label();
            this.shopperNameTextBox = new System.Windows.Forms.TextBox();
            this.shopperMoneyTextBox = new System.Windows.Forms.TextBox();
            this.createShopperButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // shopperNameLabel
            // 
            this.shopperNameLabel.AutoSize = true;
            this.shopperNameLabel.Location = new System.Drawing.Point(12, 9);
            this.shopperNameLabel.Name = "shopperNameLabel";
            this.shopperNameLabel.Size = new System.Drawing.Size(86, 13);
            this.shopperNameLabel.TabIndex = 0;
            this.shopperNameLabel.Text = "Shopper\'s name:";
            // 
            // shopperMoneyLabel
            // 
            this.shopperMoneyLabel.AutoSize = true;
            this.shopperMoneyLabel.Location = new System.Drawing.Point(12, 53);
            this.shopperMoneyLabel.Name = "shopperMoneyLabel";
            this.shopperMoneyLabel.Size = new System.Drawing.Size(136, 13);
            this.shopperMoneyLabel.TabIndex = 1;
            this.shopperMoneyLabel.Text = "Shopper\'s available money:";
            // 
            // shopperNameTextBox
            // 
            this.shopperNameTextBox.Location = new System.Drawing.Point(238, 6);
            this.shopperNameTextBox.Name = "shopperNameTextBox";
            this.shopperNameTextBox.Size = new System.Drawing.Size(170, 20);
            this.shopperNameTextBox.TabIndex = 2;
            // 
            // shopperMoneyTextBox
            // 
            this.shopperMoneyTextBox.Location = new System.Drawing.Point(238, 50);
            this.shopperMoneyTextBox.Name = "shopperMoneyTextBox";
            this.shopperMoneyTextBox.Size = new System.Drawing.Size(170, 20);
            this.shopperMoneyTextBox.TabIndex = 3;
            // 
            // createShopperButton
            // 
            this.createShopperButton.Location = new System.Drawing.Point(163, 105);
            this.createShopperButton.Name = "createShopperButton";
            this.createShopperButton.Size = new System.Drawing.Size(114, 23);
            this.createShopperButton.TabIndex = 4;
            this.createShopperButton.Text = "Create Shopper";
            this.createShopperButton.UseVisualStyleBackColor = true;
            this.createShopperButton.Click += new System.EventHandler(this.createShopperButton_Click);
            // 
            // CreateShopperForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(420, 140);
            this.Controls.Add(this.createShopperButton);
            this.Controls.Add(this.shopperMoneyTextBox);
            this.Controls.Add(this.shopperNameTextBox);
            this.Controls.Add(this.shopperMoneyLabel);
            this.Controls.Add(this.shopperNameLabel);
            this.Name = "CreateShopperForm";
            this.Text = "AddShopperForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label shopperNameLabel;
        private System.Windows.Forms.Label shopperMoneyLabel;
        private System.Windows.Forms.TextBox shopperNameTextBox;
        private System.Windows.Forms.TextBox shopperMoneyTextBox;
        private System.Windows.Forms.Button createShopperButton;
    }
}