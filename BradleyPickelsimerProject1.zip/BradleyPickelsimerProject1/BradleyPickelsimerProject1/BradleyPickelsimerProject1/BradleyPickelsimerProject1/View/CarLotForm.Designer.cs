﻿namespace BradleyPickelsimerProject1.View
{
    partial class CarLotForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addShopperButton = new System.Windows.Forms.Button();
            this.shopperNameLabel = new System.Windows.Forms.Label();
            this.shopperNameTextBox = new System.Windows.Forms.TextBox();
            this.shopperMoneyLabel = new System.Windows.Forms.Label();
            this.shopperMoneyTextBox = new System.Windows.Forms.TextBox();
            this.inventoryLabel = new System.Windows.Forms.Label();
            this.inventoryListBox = new System.Windows.Forms.ListBox();
            this.purchaseCarButton = new System.Windows.Forms.Button();
            this.inventoryDetailsLabel = new System.Windows.Forms.Label();
            this.purchasedCarsLabel = new System.Windows.Forms.Label();
            this.purchasedCarsListBox = new System.Windows.Forms.ListBox();
            this.inventoryDetailsTextBox = new System.Windows.Forms.TextBox();
            this.searchByMakeButton = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1200, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(54, 29);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.openToolStripMenuItem.Size = new System.Drawing.Size(223, 34);
            this.openToolStripMenuItem.Text = "&Open";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(223, 34);
            this.saveToolStripMenuItem.Text = "&Save";
            // 
            // addShopperButton
            // 
            this.addShopperButton.Location = new System.Drawing.Point(95, 643);
            this.addShopperButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.addShopperButton.Name = "addShopperButton";
            this.addShopperButton.Size = new System.Drawing.Size(162, 35);
            this.addShopperButton.TabIndex = 1;
            this.addShopperButton.Text = "Add Shopper";
            this.addShopperButton.UseVisualStyleBackColor = true;
            this.addShopperButton.Click += new System.EventHandler(this.addShopperButton_Click);
            // 
            // shopperNameLabel
            // 
            this.shopperNameLabel.AutoSize = true;
            this.shopperNameLabel.Location = new System.Drawing.Point(13, 301);
            this.shopperNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.shopperNameLabel.Name = "shopperNameLabel";
            this.shopperNameLabel.Size = new System.Drawing.Size(129, 20);
            this.shopperNameLabel.TabIndex = 2;
            this.shopperNameLabel.Text = "Shopper\'s name:";
            // 
            // shopperNameTextBox
            // 
            this.shopperNameTextBox.Location = new System.Drawing.Point(222, 295);
            this.shopperNameTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.shopperNameTextBox.Name = "shopperNameTextBox";
            this.shopperNameTextBox.Size = new System.Drawing.Size(224, 26);
            this.shopperNameTextBox.TabIndex = 3;
            // 
            // shopperMoneyLabel
            // 
            this.shopperMoneyLabel.AutoSize = true;
            this.shopperMoneyLabel.Location = new System.Drawing.Point(13, 341);
            this.shopperMoneyLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.shopperMoneyLabel.Name = "shopperMoneyLabel";
            this.shopperMoneyLabel.Size = new System.Drawing.Size(201, 20);
            this.shopperMoneyLabel.TabIndex = 4;
            this.shopperMoneyLabel.Text = "Shopper\'s available money:";
            // 
            // shopperMoneyTextBox
            // 
            this.shopperMoneyTextBox.Location = new System.Drawing.Point(222, 338);
            this.shopperMoneyTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.shopperMoneyTextBox.Name = "shopperMoneyTextBox";
            this.shopperMoneyTextBox.Size = new System.Drawing.Size(224, 26);
            this.shopperMoneyTextBox.TabIndex = 5;
            // 
            // inventoryLabel
            // 
            this.inventoryLabel.AutoSize = true;
            this.inventoryLabel.Location = new System.Drawing.Point(12, 61);
            this.inventoryLabel.Name = "inventoryLabel";
            this.inventoryLabel.Size = new System.Drawing.Size(78, 20);
            this.inventoryLabel.TabIndex = 6;
            this.inventoryLabel.Text = "Inventory:";
            // 
            // inventoryListBox
            // 
            this.inventoryListBox.FormattingEnabled = true;
            this.inventoryListBox.ItemHeight = 20;
            this.inventoryListBox.Location = new System.Drawing.Point(16, 84);
            this.inventoryListBox.Name = "inventoryListBox";
            this.inventoryListBox.Size = new System.Drawing.Size(599, 184);
            this.inventoryListBox.TabIndex = 7;
            // 
            // purchaseCarButton
            // 
            this.purchaseCarButton.Location = new System.Drawing.Point(548, 643);
            this.purchaseCarButton.Name = "purchaseCarButton";
            this.purchaseCarButton.Size = new System.Drawing.Size(144, 35);
            this.purchaseCarButton.TabIndex = 8;
            this.purchaseCarButton.Text = "Purchase Car";
            this.purchaseCarButton.UseVisualStyleBackColor = true;
            this.purchaseCarButton.Click += new System.EventHandler(this.purchaseCarButton_Click);
            // 
            // inventoryDetailsLabel
            // 
            this.inventoryDetailsLabel.AutoSize = true;
            this.inventoryDetailsLabel.Location = new System.Drawing.Point(645, 61);
            this.inventoryDetailsLabel.Name = "inventoryDetailsLabel";
            this.inventoryDetailsLabel.Size = new System.Drawing.Size(131, 20);
            this.inventoryDetailsLabel.TabIndex = 9;
            this.inventoryDetailsLabel.Text = "Inventory Details:";
            // 
            // purchasedCarsLabel
            // 
            this.purchasedCarsLabel.AutoSize = true;
            this.purchasedCarsLabel.Location = new System.Drawing.Point(12, 382);
            this.purchasedCarsLabel.Name = "purchasedCarsLabel";
            this.purchasedCarsLabel.Size = new System.Drawing.Size(198, 20);
            this.purchasedCarsLabel.TabIndex = 10;
            this.purchasedCarsLabel.Text = "Shopper\'s purchased cars:";
            // 
            // purchasedCarsListBox
            // 
            this.purchasedCarsListBox.FormattingEnabled = true;
            this.purchasedCarsListBox.ItemHeight = 20;
            this.purchasedCarsListBox.Location = new System.Drawing.Point(17, 417);
            this.purchasedCarsListBox.Name = "purchasedCarsListBox";
            this.purchasedCarsListBox.Size = new System.Drawing.Size(598, 184);
            this.purchasedCarsListBox.TabIndex = 11;
            // 
            // inventoryDetailsTextBox
            // 
            this.inventoryDetailsTextBox.Location = new System.Drawing.Point(649, 84);
            this.inventoryDetailsTextBox.Multiline = true;
            this.inventoryDetailsTextBox.Name = "inventoryDetailsTextBox";
            this.inventoryDetailsTextBox.Size = new System.Drawing.Size(524, 517);
            this.inventoryDetailsTextBox.TabIndex = 12;
            // 
            // searchByMakeButton
            // 
            this.searchByMakeButton.Location = new System.Drawing.Point(944, 643);
            this.searchByMakeButton.Name = "searchByMakeButton";
            this.searchByMakeButton.Size = new System.Drawing.Size(158, 35);
            this.searchByMakeButton.TabIndex = 13;
            this.searchByMakeButton.Text = "Search By Make";
            this.searchByMakeButton.UseVisualStyleBackColor = true;
            this.searchByMakeButton.Click += new System.EventHandler(this.searchByMakeButton_Click);
            // 
            // CarLotForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.searchByMakeButton);
            this.Controls.Add(this.inventoryDetailsTextBox);
            this.Controls.Add(this.purchasedCarsListBox);
            this.Controls.Add(this.purchasedCarsLabel);
            this.Controls.Add(this.inventoryDetailsLabel);
            this.Controls.Add(this.purchaseCarButton);
            this.Controls.Add(this.inventoryListBox);
            this.Controls.Add(this.inventoryLabel);
            this.Controls.Add(this.shopperMoneyTextBox);
            this.Controls.Add(this.shopperMoneyLabel);
            this.Controls.Add(this.shopperNameTextBox);
            this.Controls.Add(this.shopperNameLabel);
            this.Controls.Add(this.addShopperButton);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "CarLotForm";
            this.Text = "Car Lot Form";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.Button addShopperButton;
        private System.Windows.Forms.Label shopperNameLabel;
        private System.Windows.Forms.TextBox shopperNameTextBox;
        private System.Windows.Forms.Label shopperMoneyLabel;
        private System.Windows.Forms.TextBox shopperMoneyTextBox;
        private System.Windows.Forms.Label inventoryLabel;
        private System.Windows.Forms.ListBox inventoryListBox;
        private System.Windows.Forms.Button purchaseCarButton;
        private System.Windows.Forms.Label inventoryDetailsLabel;
        private System.Windows.Forms.Label purchasedCarsLabel;
        private System.Windows.Forms.ListBox purchasedCarsListBox;
        private System.Windows.Forms.TextBox inventoryDetailsTextBox;
        private System.Windows.Forms.Button searchByMakeButton;
    }
}

