﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows.Forms;
using BradleyPickelsimerProject1.Model;

namespace BradleyPickelsimerProject1.View
{
    public partial class CarLotForm : Form
    {
        /// <summary>
        /// Creates a new car lot.
        /// </summary>
        public CarLot CarLot;

        /// <summary>
        /// Creates a new shopper.
        /// </summary>
        public Shopper Shopper;

        /// <summary>
        /// Creates a new text IO.
        /// </summary>
        public TextIO.TextIo TextIo;

        private List<Car> purchasedCars;
        /// <summary>
        /// Initializes a new instance of the <see cref="CarLotForm"/> class.
        /// </summary>
        public CarLotForm()
        {
            this.InitializeComponent();
            this.CarLot = new CarLot();
            this.TextIo = new TextIO.TextIo();
            this.purchasedCars = new List<Car>();
            this.setInitialForm();
            this.setInventoryDetails();
        }

        private void setInventoryDetails()
        {
            this.inventoryDetailsTextBox.Text = "";
            if (this.CarLot.Inventory.Count == 0)
            {
                this.inventoryDetailsTextBox.Text = "";
            }
            else
            {
                this.inventoryDetailsTextBox.Text += $@"Inventory of {this.CarLot.Inventory.Count} cars." + Environment.NewLine;
                foreach (Car car in this.CarLot.Inventory)
                {
                    this.inventoryDetailsTextBox.Text += car + Environment.NewLine;
                }

                this.inventoryDetailsTextBox.Text += Environment.NewLine;
                this.inventoryDetailsTextBox.Text += @"Most expensive:" + Environment.NewLine;
                this.inventoryDetailsTextBox.Text += $@"{this.CarLot.FindMostExpensiveCar()}" + Environment.NewLine;
                this.inventoryDetailsTextBox.Text += Environment.NewLine;
                this.inventoryDetailsTextBox.Text += @"Least expensive:" + Environment.NewLine;
                this.inventoryDetailsTextBox.Text += $@"{this.CarLot.FindLeastExpensiveCar()}" + Environment.NewLine;
                this.inventoryDetailsTextBox.Text += Environment.NewLine;
                this.inventoryDetailsTextBox.Text += @"Best MPG:" + Environment.NewLine;
                this.inventoryDetailsTextBox.Text += $@"{this.CarLot.FindBestMpgCar()}" + Environment.NewLine;
                this.inventoryDetailsTextBox.Text += Environment.NewLine;
                this.inventoryDetailsTextBox.Text += @"Worst MPG:" + Environment.NewLine;
                this.inventoryDetailsTextBox.Text += $@"{this.CarLot.FindWorstMpgCar()}" + Environment.NewLine;
            }
        }

        private void setInitialForm()
        {
            this.inventoryListBox.DataSource = this.CarLot.Inventory;
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var loadDialog = new OpenFileDialog();
            loadDialog.InitialDirectory = "*.lot";
            loadDialog.Filter = @"lot files (*.lot)|*.lot|txt files (*.txt)|*.txt|All files (*.*)|*.*";

            var result = loadDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                this.CarLot = this.TextIo.ReadViaStreamReader(loadDialog.FileName);
                this.setInventoryDetails();
                this.setInitialForm();
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var saveDialog = new SaveFileDialog();
            saveDialog.InitialDirectory = "*.lot";
            saveDialog.Filter = @"lot files (*.lot)|*.lot|txt files (*.txt)|*.txt|All files (*.*)|*.*";

            var result = saveDialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                this.TextIo.WriteViaStreamWriter(saveDialog.FileName, this.CarLot.Inventory);
            }
        }

        private void addShopperButton_Click(object sender, EventArgs e)
        {
            var shopperForm = new CreateShopperForm();
            if (shopperForm.ShowDialog() == DialogResult.OK)
            {
                this.shopperNameTextBox.Text = shopperForm.Shopper.Name;
                this.shopperMoneyTextBox.Text =
                    shopperForm.Shopper.MoneyAvailable.ToString("C", CultureInfo.CurrentCulture);
                this.Shopper = new Shopper(shopperForm.Shopper.Name, shopperForm.Shopper.MoneyAvailable);
            }
        }

        private void purchaseCarButton_Click(object sender, EventArgs e)
        {
            try
            {
                var carToPurchase = (Car)this.inventoryListBox.SelectedItem;
                if (this.Shopper.CanPurchase(carToPurchase))
                {
                    this.CarLot.Inventory.Remove(carToPurchase);
                    this.Shopper.PurchaseCar(carToPurchase);
                    this.updateShopperMoney();
                    this.updateInventoryListBox();
                    this.setInventoryDetails();
                    this.setPurchasedCarsListBox(carToPurchase);
                    MessageBox.Show(
                        $@"Congratulations on the purchase of your new {carToPurchase.Make} {carToPurchase.Model}!");
                }
                else
                {
                    MessageBox.Show(
                        $@"The current shopper does not have enough available funds to purchase this {carToPurchase.Make} {carToPurchase.Model}.");
                }
            }
            catch (NullReferenceException)
            {
                MessageBox.Show(@"No shopper has been created.");
            }
        }

        private void setPurchasedCarsListBox(Car carToPurchase)
        {
            this.purchasedCars.Add(carToPurchase);
            this.purchasedCarsListBox.DataSource = null;
            this.purchasedCarsListBox.DataSource = this.purchasedCars;
        }

        private void updateShopperMoney()
        {
            this.shopperMoneyTextBox.Text = "";
            this.shopperMoneyTextBox.Text = this.Shopper.MoneyAvailable.ToString("C", CultureInfo.CurrentCulture);
        }

        private void updateInventoryListBox()
        {
            this.inventoryListBox.DataSource = null;
            this.inventoryListBox.DataSource = this.CarLot.Inventory;
        }

        private void searchByMakeButton_Click(object sender, EventArgs e)
        {
            List<Car> matchingCars = new List<Car>();
                var searchByMakeForm = new SearchByMakeForm();
            if (searchByMakeForm.ShowDialog() == DialogResult.OK)
            {
                foreach (Car car in this.CarLot.Inventory)
                {
                    if (car.Make.ToLower() == searchByMakeForm.SearchPhrase)
                    {
                        matchingCars.Add(car);
                    }
                }

                if (matchingCars.Count == 0)
                {
                    MessageBox.Show(@"There are no cars matching that make.");
                }
                else
                {
                    this.inventoryListBox.DataSource = matchingCars;
                }
            }
        }
    }
}
