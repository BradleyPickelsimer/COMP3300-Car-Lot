﻿using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using BradleyPickelsimerProject1.Model;

namespace BradleyPickelsimerProject1.TextIO
{
    /// <summary>
    ///     A class dictating how to read and write files.
    /// </summary>
    public class TextIo
    {
        #region Methods

        /// <summary>
        ///     Reads in data from a file and creates a car lot of cars from the data.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <returns>A car lot of cars.</returns>
        public CarLot ReadViaStreamReader(string fileName)
        {
            var carLot = new CarLot();
            try
            {
                using (var sr = new StreamReader(fileName))
                {
                    while (sr.Peek() >= 0)
                    {
                        var line = sr.ReadLine();
                        Debug.Assert(line != null, nameof(line) + " != null");
                        var carInfo = line.Split(',');
                        var make = carInfo[0];
                        var model = carInfo[1];
                        var mpg = double.Parse(carInfo[2]);
                        var price = double.Parse(carInfo[3]);
                        carLot.AddCar(make, model, mpg, price);
                    }
                }
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show(ex.Message);
            }

            return carLot;
        }

        public void WriteViaStreamWriter(string fileName, List<Car> cars)
        {
            using (var outputFile = new StreamWriter(fileName))
            {
                foreach (var car in cars)
                {
                    var make = car.Make;
                    var model = car.Model;
                    var mpg = car.Mpg;
                    var price = car.Price;
                    var outLine = $"{make},{model},{mpg},{price}";
                    outputFile.WriteLine(outLine);
                }
            }
        }

        #endregion
    }
}